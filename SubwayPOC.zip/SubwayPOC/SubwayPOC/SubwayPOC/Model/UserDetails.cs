﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SubwayPOC.Model
{
    class UserDetails
    {
        public string username { get; set; }
        public int userId { get; set; }
    }
}
