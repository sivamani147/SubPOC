﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SubwayPOC.Model
{
    public class RequestInformation
    {
        public string requestType { get; set; }
        public string requestId { get; set; }

        public DateTime todaysDate { get; set; }
        public DateTime requestDate { get; set; }
        public string country { get; set; }
        public string markets { get; set; }
        public DateTime promotionStartDate { get; set; }
        public DateTime promotionEndDate { get; set; }
        public string menuItemType { get; set; }
        public string menuItemDescription { get; set; }

        //for countries req add info 
        public string translationDescription { get; set; }
        public string shortDescription { get; set; }

        public string posTextLine1 { get; set; }
        public string posTextLine2 { get; set; }
        public string posTextLine3 { get; set; }
        
        public string campaignType { get; set; }
        public int noofrestaurantsParticipating { get; set; }
        //public string requestType { get; set; }
        //public string requestType { get; set; }

        public bool isCreativeMaterialsSubmittedWithRequest { get; set; }
        public bool isPromotionGoneThruARB { get; set; }

        public bool doesDiscountIncludeNewMenuItem { get; set; }

        public string discountBeingAdvertisedThru { get; set; }
        public Attachment attachment { get; set; }

        public string additionalInfo { get; set; }
    }
}
