﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SubwayPOC.Model
{
    public class Attachment
    {
        //setters
        public byte[] data { get; set; }
        public string mediaType { get; set; }
        public string fileName { get; set; }

        //getters
        public string blobUrl { get; set; }


    }
}
