﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SubwayPOC.Model
{
    public class Constants
    {
        //public static string webApiUrl = "https://subwaypocwebapi.azurewebsites.net/api/RequestInformation/CreateRequest";
        //public static string webApiUrl = "https://localhost:55575/api/RequestInformation/CreateRequest";
        public static string webApiUrl = "http://10.211.118.40:55575/api/RequestInformation/CreateRequest";

    }
}
