﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace SubwayPOC
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Homepages : MasterDetailPage
    {
        public Homepages()
        {
            InitializeComponent();
            Detail = new NavigationPage(new GeneralInformation());
            IsPresented = false;
          
        }

        private void Button_Clicked(object sender, EventArgs e)
        {
            Detail = new NavigationPage(new TabbedPage1());
            IsPresented = false;

        }

        private void Button_Clicked_1(object sender, EventArgs e)
        {
            Detail = new NavigationPage(new View.Disclaimers());
            IsPresented = false;
        }


    }
}