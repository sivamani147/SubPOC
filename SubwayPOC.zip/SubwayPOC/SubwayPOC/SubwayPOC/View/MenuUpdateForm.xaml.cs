﻿
using Plugin.FilePicker;
using Plugin.FilePicker.Abstractions;
using SubwayPOC.HelperClasses;
using SubwayPOC.Model;
using SubwayPOC.ViewModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace SubwayPOC
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MenuUpdateForm : ContentPage
    {
        public MenuUpdateForm()
        {
            InitializeComponent();
            BindingContext = new MenuUpdateFormViewModel();
            if (Device.RuntimePlatform == Device.iOS)
            {
                Padding = new Thickness(0, 40, 0, 0);
            }
        }

        

        private void entCountry_Unfocused(object sender, FocusEventArgs e)
        {
            if (entCountry.Text == null || entCountry.Text.Length < 3)
                entCountry.Focus();
            else
                entRequestId.Text = (entCountry.Text.Substring(0, 2)) + "-" + entReqType.SelectedItem.ToString().Substring(0, 3) + "-" + new Random().Next(1, 200);
        }

        private void entReqType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (entCountry.Text== null || entCountry.Text.Length<3)
                entCountry.Focus();
            else
                entRequestId.Text = (entCountry.Text.Substring(0, 2)) + "-" + entReqType.SelectedItem.ToString().Substring(0, 3) + "-" + new Random().Next(1, 200);

            var layout = (ScrollView)this.Content;

            foreach (Xamarin.Forms.View i in ((StackLayout)layout.Children[0]).Children.Where(x => x.ClassId == "noForDesc"))
            {
                if (entReqType.SelectedItem.Equals("Discount"))
                {
                    i.IsVisible = false;
                }
                else
                    i.IsVisible = true;

            }

        }

        public async Task ButtonClick_AttachItem(object sender, EventArgs e)
        {
            try
            {
                FileData fileData = new FileData();
                fileData = await CrossFilePicker.Current.PickFile();
                if(fileData==null)
                {
                    return;
                }
                Attachment objAttachment = new Attachment();
                objAttachment.data = fileData.DataArray;
                string filePath = fileData.FilePath;
                string ext = Path.GetExtension(filePath);
                objAttachment.mediaType = MediaTypeMap.GetMimeType(ext).ToString();
                objAttachment.fileName = fileData.FileName;
                await AzureStorage.performBlobOperation(objAttachment);
                
               
                
            }
            catch (Exception ex)
            {
                throw ex.InnerException;

            }
        }

        private void ButtonClicked_Submit(object sender, EventArgs e)
        {

            //get the items values
            //send to db

            RequestInformation requestInformation = new RequestInformation();
            requestInformation.requestId = entRequestId.Text.ToString();
            requestInformation.requestType = entReqType.SelectedItem.ToString();
            requestInformation.promotionStartDate = DateTime.Now;

            DisplayAlert("Success", "The Form has been submitted. The ID is " + entRequestId.Text.ToString(), "OK");
        }
    }
}