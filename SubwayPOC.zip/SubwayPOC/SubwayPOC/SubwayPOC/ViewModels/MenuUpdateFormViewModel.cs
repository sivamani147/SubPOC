﻿using SubwayPOC.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace SubwayPOC.ViewModels
{
    class MenuUpdateFormViewModel : ViewModelBase
    {
        public MenuUpdateFormViewModel()
        {
            _Model = new RequestInformation();
        }

        private RequestInformation _Model;
        public RequestInformation objRequestInformation
        {
            get { return _Model; }
            set
            {
                _Model = objRequestInformation;
                OnPropertyChanged();
            }
        }

        //public RequestInformation objRequestInformation { get; set; }
      
    }
}
