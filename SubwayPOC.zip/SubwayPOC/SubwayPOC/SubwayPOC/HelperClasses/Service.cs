﻿using Newtonsoft.Json;
using SubwayPOC.Model;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace SubwayPOC.HelperClasses
{
    public class Service
    {
        public static async Task SaveRequestInfo(RequestInformation item)
        {

            try
            {

            
            // RestUrl = http://developer.xamarin.com:8081/api/todoitems/
            var uri = new Uri(string.Format(Constants.webApiUrl, string.Empty));

            var json = JsonConvert.SerializeObject(item);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            HttpClient client = new HttpClient();
            HttpResponseMessage response = null;


                //var userDetails = userDetailsResponse.Content.ReadAsStringAsync().Result;
                //var json_serializer = new JsonConvert();
                //var customerDetails = JsonConvert.DeserializeObject<CustomerEntity>(userDetails);


                response = await client.PostAsync(uri, content);
            
            if (response.IsSuccessStatusCode)
            {
                //Debug.WriteLine(@"                TodoItem successfully saved.");

            }
            }
            catch (Exception Ex)
            {

                throw;
            }
        }
    }
}
