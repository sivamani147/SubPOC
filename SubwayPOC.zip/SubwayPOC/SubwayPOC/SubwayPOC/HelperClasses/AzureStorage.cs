﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using SubwayPOC.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace SubwayPOC.HelperClasses
{
    class AzureStorage
    {
        public static async Task performBlobOperation(Attachment objAttachment)
        {
            try
            {

           // Retrieve storage account from connection string.
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse("DefaultEndpointsProtocol=https;AccountName=tacobothandoffbeff;AccountKey=XUT0cxvHvdDUd6wRKuQ1k6YdnUOe6XMl/ync4gSwL/PXlYniPUqzwnva0HFO68DinCWn3p8tgbIGOXCDRCRj2A==");

            // Create the blob client.
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();

            // Retrieve reference to a previously created container.
            CloudBlobContainer container = blobClient.GetContainerReference("subwaypoccontainer");
            
            // Create the container if it doesn't already exist.
            await container.CreateIfNotExistsAsync();

            // Retrieve reference to a blob named "myblob".
            CloudBlockBlob blockBlob = container.GetBlockBlobReference(objAttachment.fileName.ToString());
            await container.SetPermissionsAsync(
            new BlobContainerPermissions { PublicAccess = BlobContainerPublicAccessType.Container });
                //// Create the "myblob" blob with the text "Hello, world!"
                //await blockBlob.UploadTextAsync("Hello, world!");

                // Create the "myblob" blob with the text "Hello, world!"
                //await blockBlob.UploadFromByteArrayAsync(bytes,);
                blockBlob.Properties.ContentType = objAttachment.mediaType;
                await blockBlob.UploadFromByteArrayAsync(objAttachment.data, 0, objAttachment.data.Length);
                var blobUrl = blockBlob.Uri.AbsoluteUri;
                objAttachment.blobUrl = blobUrl;
            }
            catch (Exception)
            {

                throw;
            }
            
        }
    }
}
